<?php

$_['matrix'] = [
	'version' => '0.1.0',

	// Default
	'setting' => [
		'status' => 0,
		'debug'  => 1,
	],
];
