<?php
$_['heading_title']    = 'Matrix Theme';

// Text
$_['text_extension']   = 'Extensions';
$_['text_success']     = 'Success: You have modified Matrix theme!';
$_['text_edit']        = 'Edit Matrix Theme';

// Entry
$_['entry_status']     = 'Status';
$_['entry_debug']      = 'Debug';

// Error
$_['error_permission'] = 'Warning: You do not have permission to modify Matrix theme!';
